﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.BindRepeater();
            }
        }

        protected void repeater_1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            Repeater rpt = (Repeater)e.Item.FindControl("repeater_2");
            rpt.DataSource = this.getPeopleData().GroupBy(a => a.qty).ToList()[e.Item.ItemIndex];
            rpt.DataBind();

        }
        private List<People> getPeopleData()
        {
            List<People> data = new List<People>();
            using (PeopleEntities context = new PeopleEntities())
            {

                data = context.staffs.Select(s => new People
                {
                    id = s.id,
                    qty = s.qty,
                    total = s.total
                }).ToList();

            }
            return data;
        }

        protected void id_TextChanged(object sender, EventArgs e)
        {
            GridViewRow row = ((GridViewRow)((TextBox)sender).NamingContainer);
            Label other = (Label)row.FindControl("name");
            other.Text = other.Text + row.DataItemIndex;
            SCPanel.Update();
        }

        protected void id_PreRender(object sender, EventArgs e)
        {

        }

        protected void repeater_2_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {

        }
        protected void OnUpdate(object sender, EventArgs e)
        {
            //Find the reference of the Repeater Item.
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            int customerId = int.Parse((item.FindControl("id") as Label).Text);
            int name = int.Parse((item.FindControl("qty") as TextBox).Text.Trim());
            int total = customerId * name;


            using (PeopleEntities db = new PeopleEntities())
            {
                var m = db.staffs.Where(d => d.id == customerId).First();
                m.qty = name;
                m.total = total;
                db.SaveChanges();
            }

            this.BindRepeater();
        }

        private void BindRepeater()
        {
            var data = getPeopleData().GroupBy(a => a.qty);
            repeater_1.DataSource = data;
            repeater_1.DataBind();
            SCPanel.Update();
        }


        protected void qty_Init(object sender, EventArgs e)
        {
            RepeaterItem item = (sender as TextBox).Parent as RepeaterItem;
            string id = (item.FindControl("id") as Label).ClientID;
            string total = (item.FindControl("total") as Label).ClientID;

            TextBox c = (sender as TextBox) as TextBox;

            string y = c.ClientID;
            c.Attributes.Add("onkeyup", "OnKeyUpQty('"+id+"','"+total+"','"+y+"')");

            
          
        }
    }
}

public class People
{
    public int id { get; set; }
    public int? qty { get; set; }
    public int? total { get; set; }
}