﻿(function changed(context) {
    console.log(context);
})()